package pe.edu.upc.equipovirtual1.servicesinterfaces;

public interface ICategoryService {
}

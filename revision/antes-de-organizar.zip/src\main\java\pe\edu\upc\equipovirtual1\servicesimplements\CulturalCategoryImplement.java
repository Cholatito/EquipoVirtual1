package pe.edu.upc.equipovirtual1.servicesimplements;

import org.example.pc.dtos.CulturalCategoryDTO;
import org.example.pc.entities.CulturalCategory;
import org.example.pc.repositories.CulturalCategoryRepository;
import org.springframework.stereotype.Service;

public class CulturalCategoryImplement {

    @Service
    public class CulturalCategoryService {

        private final CulturalCategoryRepository e2_repository;

        public CulturalCategoryService(CulturalCategoryRepository e2_repository) {
            this.e2_repository = e2_repository;
        }

        public CulturalCategory e2_registrarCategoria(CulturalCategory CuC) {


            return  e2_repository.save(CuC);


        }
    }
}
package pe.edu.upc.equipovirtual1.repositories;

public interface IActivityRepository {
}

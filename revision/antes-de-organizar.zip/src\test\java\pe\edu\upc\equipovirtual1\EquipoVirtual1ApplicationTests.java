package pe.edu.upc.equipovirtual1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EquipoVirtual1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
